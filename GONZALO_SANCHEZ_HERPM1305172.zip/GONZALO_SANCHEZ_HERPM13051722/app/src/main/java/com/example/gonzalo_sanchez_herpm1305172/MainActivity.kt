package com.example.gonzalo_sanchez_herpm1305172
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity  : AppCompatActivity() {

    private lateinit var listView: ListView
    private lateinit var adapter: AdaptadorCamara
    private val camaraList = mutableListOf<Camara>()

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.listaVista)
        adapter = AdaptadorCamara(this, camaraList)
        listView.adapter = adapter

        // Registrar la vista para el menú contextual
        registerForContextMenu(listView)

        // Agregar algunas cámaras a la lista
        camaraList.add(Camara(R.drawable.ic_camara, "Bullet", "Modelo1", "$29990"))
        camaraList.add(Camara(R.drawable.ic_camara2, "Yoosee", "Modelo2", "$39990"))

        // Configurar el clic en el ítem del ListView
        listView.setOnItemClickListener { _, _, position, _ ->
            val camaraSeleccionada = camaraList[position]
            val intent = Intent(this, ActividadDetalle::class.java).apply {
                putExtra("CAMARA_IMAGEN", camaraSeleccionada.imagen)
                putExtra("CAMARA_MARCA", camaraSeleccionada.marca)
                putExtra("CAMARA_MODELO", camaraSeleccionada.modelo)
                putExtra("CAMARA_PRECIO", camaraSeleccionada.precio)
            }
            startActivity(intent)
        }
    }

    override fun onCreateContextMenu(menu: ContextMenu, v: View, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menu_contextual, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        val info = item.menuInfo as AdapterView.AdapterContextMenuInfo
        return when (item.itemId) {
            R.id.eliminar -> {
                // Lógica para eliminar la cámara del listado
                camaraList.removeAt(info.position)
                adapter.notifyDataSetChanged()
                Toast.makeText(this, "Cámara eliminada", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }
}
