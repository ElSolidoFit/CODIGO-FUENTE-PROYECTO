package com.example.gonzalo_sanchez_herpm1305172
import android.annotation.SuppressLint
import android.os.Bundle
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ActividadDetalle : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.actividad_detalle)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val imageView = findViewById<ImageView>(R.id.imagen_detalle)
        val brandTextView = findViewById<TextView>(R.id.texto_marca_detalle)
        val modelTextView = findViewById<TextView>(R.id.texto_modelo_detalle)
        val priceTextView = findViewById<TextView>(R.id.texto_precio_detalle)

        val imagen = intent.getIntExtra("CAMARA_IMAGEN", 0)
        val marca = intent.getStringExtra("CAMARA_MARCA")
        val modelo = intent.getStringExtra("CAMARA_MODELO")
        val precio = intent.getStringExtra("CAMARA_PRECIO")

        imageView.setImageResource(imagen)
        brandTextView.text = marca
        modelTextView.text = modelo
        priceTextView.text = precio
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
