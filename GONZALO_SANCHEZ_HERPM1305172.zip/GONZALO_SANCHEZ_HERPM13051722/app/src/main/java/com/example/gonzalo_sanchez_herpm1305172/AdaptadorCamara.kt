package com.example.gonzalo_sanchez_herpm1305172
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class AdaptadorCamara(private val context: Context, private val dataSource: List<Camara>) : BaseAdapter() {

    private val inflater: LayoutInflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int = dataSource.size

    override fun getItem(position: Int): Any = dataSource[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val rowView = convertView ?: inflater.inflate(R.layout.elemento_lista_camara, parent, false)
        val imageView = rowView.findViewById<ImageView>(R.id.imagen_camara)
        val brandTextView = rowView.findViewById<TextView>(R.id.texto_marca)
        val modelTextView = rowView.findViewById<TextView>(R.id.texto_modelo)

        val camara = getItem(position) as Camara
        imageView.setImageResource(camara.imagen)
        brandTextView.text = camara.marca
        modelTextView.text = camara.modelo

        return rowView
    }
}


