package com.example.gonzalo_sanchez_herpm1305172
data class Camara(val imagen: Int, val marca: String, val modelo: String, val precio: String)
