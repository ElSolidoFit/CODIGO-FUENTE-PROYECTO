package com.example.gonzalo_sanchez_seccioncurso

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var foodNameEditText: EditText
    private lateinit var quantityEditText: EditText
    private lateinit var addressEditText: EditText
    private lateinit var submitButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        foodNameEditText = findViewById(R.id.foodNameEditText)
        quantityEditText = findViewById(R.id.quantityEditText)
        addressEditText = findViewById(R.id.addressEditText)
        submitButton = findViewById(R.id.submitButton)

        submitButton.setOnClickListener {
            val foodName = foodNameEditText.text.toString()
            val quantity = quantityEditText.text.toString()
            val address = addressEditText.text.toString()

            val orderInfo = "Pedido: $foodName, Cantidad: $quantity, Dirección: $address"
            Toast.makeText(this, orderInfo, Toast.LENGTH_LONG).show()
            Log.d("MainActivity", orderInfo)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("MainActivity", "La aplicación ha sido cerrada.")
    }
}
